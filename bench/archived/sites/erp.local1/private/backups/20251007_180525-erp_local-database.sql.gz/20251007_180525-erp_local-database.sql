-- begin frappe metadata
-- [frappe]
-- version = 15.84.0
-- branch = version-15
-- end frappe metadata
-- 
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.0.2-MariaDB, for osx10.20 (arm64)
--
-- Host: 127.0.0.1    Database: _52757c7bdde86aa0
-- ------------------------------------------------------
-- Server version	11.8.3-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `__Auth`
--

DROP TABLE IF EXISTS `__Auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `__Auth` (
  `doctype` varchar(140) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fieldname` varchar(140) NOT NULL,
  `password` text NOT NULL,
  `encrypted` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`doctype`,`name`,`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__Auth`
--

LOCK TABLES `__Auth` WRITE;
/*!40000 ALTER TABLE `__Auth` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `__Auth` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `__UserSettings`
--

DROP TABLE IF EXISTS `__UserSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `__UserSettings` (
  `user` varchar(180) NOT NULL,
  `doctype` varchar(180) NOT NULL,
  `data` text DEFAULT NULL,
  UNIQUE KEY `user` (`user`,`doctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__UserSettings`
--

LOCK TABLES `__UserSettings` WRITE;
/*!40000 ALTER TABLE `__UserSettings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `__UserSettings` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `__global_search`
--

DROP TABLE IF EXISTS `__global_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `__global_search` (
  `doctype` varchar(100) DEFAULT NULL,
  `name` varchar(140) DEFAULT NULL,
  `title` varchar(140) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `route` varchar(140) DEFAULT NULL,
  `published` int(1) NOT NULL DEFAULT 0,
  UNIQUE KEY `doctype_name` (`doctype`,`name`),
  FULLTEXT KEY `content` (`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__global_search`
--

LOCK TABLES `__global_search` WRITE;
/*!40000 ALTER TABLE `__global_search` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `__global_search` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabDefaultValue`
--

DROP TABLE IF EXISTS `tabDefaultValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabDefaultValue` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT 0,
  `defvalue` text DEFAULT NULL,
  `defkey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `defaultvalue_parent_defkey_index` (`parent`,`defkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDefaultValue`
--

LOCK TABLES `tabDefaultValue` WRITE;
/*!40000 ALTER TABLE `tabDefaultValue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabDefaultValue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabDocField`
--

DROP TABLE IF EXISTS `tabDocField`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabDocField` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT 0,
  `fieldname` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `oldfieldname` varchar(255) DEFAULT NULL,
  `fieldtype` varchar(255) DEFAULT NULL,
  `oldfieldtype` varchar(255) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `search_index` int(1) NOT NULL DEFAULT 0,
  `show_dashboard` int(1) NOT NULL DEFAULT 0,
  `hidden` int(1) NOT NULL DEFAULT 0,
  `set_only_once` int(1) NOT NULL DEFAULT 0,
  `allow_in_quick_entry` int(1) NOT NULL DEFAULT 0,
  `print_hide` int(1) NOT NULL DEFAULT 0,
  `report_hide` int(1) NOT NULL DEFAULT 0,
  `reqd` int(1) NOT NULL DEFAULT 0,
  `bold` int(1) NOT NULL DEFAULT 0,
  `in_global_search` int(1) NOT NULL DEFAULT 0,
  `collapsible` int(1) NOT NULL DEFAULT 0,
  `unique` int(1) NOT NULL DEFAULT 0,
  `no_copy` int(1) NOT NULL DEFAULT 0,
  `allow_on_submit` int(1) NOT NULL DEFAULT 0,
  `show_preview_popup` int(1) NOT NULL DEFAULT 0,
  `trigger` varchar(255) DEFAULT NULL,
  `collapsible_depends_on` text DEFAULT NULL,
  `mandatory_depends_on` text DEFAULT NULL,
  `read_only_depends_on` text DEFAULT NULL,
  `depends_on` text DEFAULT NULL,
  `permlevel` int(11) NOT NULL DEFAULT 0,
  `ignore_user_permissions` int(1) NOT NULL DEFAULT 0,
  `width` varchar(255) DEFAULT NULL,
  `print_width` varchar(255) DEFAULT NULL,
  `columns` int(11) NOT NULL DEFAULT 0,
  `default` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `in_list_view` int(1) NOT NULL DEFAULT 0,
  `fetch_if_empty` int(1) NOT NULL DEFAULT 0,
  `in_filter` int(1) NOT NULL DEFAULT 0,
  `remember_last_selected_value` int(1) NOT NULL DEFAULT 0,
  `ignore_xss_filter` int(1) NOT NULL DEFAULT 0,
  `print_hide_if_no_value` int(1) NOT NULL DEFAULT 0,
  `allow_bulk_edit` int(1) NOT NULL DEFAULT 0,
  `in_standard_filter` int(1) NOT NULL DEFAULT 0,
  `in_preview` int(1) NOT NULL DEFAULT 0,
  `read_only` int(1) NOT NULL DEFAULT 0,
  `precision` varchar(255) DEFAULT NULL,
  `max_height` varchar(10) DEFAULT NULL,
  `length` int(11) NOT NULL DEFAULT 0,
  `translatable` int(1) NOT NULL DEFAULT 0,
  `hide_border` int(1) NOT NULL DEFAULT 0,
  `hide_days` int(1) NOT NULL DEFAULT 0,
  `hide_seconds` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `label` (`label`),
  KEY `fieldtype` (`fieldtype`),
  KEY `fieldname` (`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocField`
--

LOCK TABLES `tabDocField` WRITE;
/*!40000 ALTER TABLE `tabDocField` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tabDocField` VALUES
('ior0saejsf','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',51,'permlevel','Perm Level','permlevel','Int','Int',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\'Section Break\', \'Column Break\', \'Tab Break\'], doc.fieldtype)',0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior0t3bgh2','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',68,'documentation_url','Documentation URL',NULL,'Data',NULL,'URL',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\"Tab Break\", \"Section Break\", \"Column Break\", \"Button\", \"HTML\"], doc.fieldtype)',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior1h1lime','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',50,'column_break_13',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior2eu5f1s','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',64,'max_height','Max Height',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,10,0,0,0,0),
('ior2m7bv76','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',17,'link_filters','Link Filters',NULL,'JSON',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior2sfr0or','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',40,'in_preview','In Preview',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\'Table\', \'Table MultiSelect\'], doc.fieldtype);',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior359404q','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',23,'visibility_section','Visibility',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior3jb9m5j','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',5,'length','Length',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\'Data\', \'Link\', \'Dynamic Link\', \'Password\', \'Select\', \'Read Only\', \'Attach\', \'Attach Image\', \'Int\', \'Float\', \'Currency\', \'Percent\'], doc.fieldtype)',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior3ko41ck','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',24,'hidden','Hidden','hidden','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior3rubu18','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',3,'fieldtype','Type','fieldtype','Select','Select','Autocomplete\nAttach\nAttach Image\nBarcode\nButton\nCheck\nCode\nColor\nColumn Break\nCurrency\nData\nDate\nDatetime\nDuration\nDynamic Link\nFloat\nFold\nGeolocation\nHeading\nHTML\nHTML Editor\nIcon\nImage\nInt\nJSON\nLink\nLong Text\nMarkdown Editor\nPassword\nPercent\nPhone\nRead Only\nRating\nSection Break\nSelect\nSignature\nSmall Text\nTab Break\nTable\nTable MultiSelect\nText\nText Editor\nTime',1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Data',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior4b0qn2t','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',9,'hide_seconds','Hide Seconds',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Duration\'',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior4i1pu0q','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',56,'set_only_once','Set only once',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior4kq7ooq','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',63,'width','Width','width','Data','Data',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,10,0,0,0,0),
('ior4rctrvm','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',55,'no_copy','No Copy','no_copy','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior4t6a06q','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',25,'show_on_timeline','Show on Timeline',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.hidden',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior54o0e8k','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',42,'in_filter','In Filter','in_filter','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior5a1jdmo','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',29,'print_hide','Print Hide','print_hide','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior5hkmf3r','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',48,'allow_bulk_edit','Allow Bulk Edit',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.fieldtype == \"Table\"',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior61riv0g','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',52,'ignore_xss_filter','Ignore XSS Filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','Don\'t encode HTML tags like &lt;script&gt; or just characters like &lt; or &gt;, as they could be intentionally used in this field',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior61sdaae','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',31,'report_hide','Report Hide','report_hide','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior656j99k','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',11,'is_virtual','Virtual',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior6m3ombc','2021-08-23 17:21:28.345841','2025-10-07 17:58:50.753945','Administrator','Administrator',0,'DocType State','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior6qrsjhn','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',53,'constraints_section','Constraints',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ior7rubdff','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',10,'reqd','Mandatory','reqd','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\"Section Break\", \"Column Break\", \"Button\", \"HTML\"], doc.fieldtype)',0,0,'50px','50px',0,'0',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iora2vpvku','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',12,'search_index','Index','search_index','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioradskkj3','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',18,'defaults_section','Defaults',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'2rem',0,0,0,0,0),
('iorbr73tr6','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',32,'column_break_28',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorcpcmgtc','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',30,'print_hide_if_no_value','Print Hide If No Value',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\"Int\", \"Float\", \"Currency\", \"Percent\"].indexOf(doc.fieldtype)!==-1',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iord980dhh','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',20,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioreuootl7','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',59,'mandatory_depends_on','Mandatory Depends On (JS)',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',0,0,0,0,0),
('iorf3bcj1b','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',22,'fetch_if_empty','Fetch on Save if Empty',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','If unchecked, the value will always be re-fetched on save.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorf79iaec','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',44,'permissions','Permissions',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorfe402ge','2021-08-23 17:21:28.345841','2025-10-07 17:58:50.753945','Administrator','Administrator',0,'DocType State','fields','DocType',3,'custom','Custom',NULL,'Check',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorfkbuhal','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',33,'depends_on','Display Depends On (JS)','depends_on','Code','Data','JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',255,0,0,0,0),
('iorfu7l4o7','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',36,'hide_border','Hide Border',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Section Break\'',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorg4vam8b','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',54,'unique','Unique',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorgg2llfa','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',43,'in_global_search','In Global Search',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:([\"Data\", \"Select\", \"Table\", \"Text\", \"Text Editor\", \"Link\", \"Small Text\", \"Long Text\", \"Read Only\", \"Heading\", \"Dynamic Link\"].indexOf(doc.fieldtype) !== -1)',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorgh2udcr','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',45,'read_only','Read Only',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorha6da9e','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',34,'collapsible','Collapsible',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype===\"Section Break\"',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,255,0,0,0,0),
('ioridkinqn','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',60,'read_only_depends_on','Read Only Depends On (JS)',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',0,0,0,0,0),
('iorifrjvlg','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',66,'column_break_22',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorj01t4r9','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',7,'non_negative','Non Negative',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\"Int\", \"Float\", \"Currency\"], doc.fieldtype)',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorji0bdci','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',41,'column_break_35',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorjkq4dna','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',35,'collapsible_depends_on','Collapsible Depends On (JS)',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\"Section Break\" && doc.collapsible',0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',0,0,0,0,0),
('iorjr7kn6k','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',58,'column_break_38',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorktndkub','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',1,'label_and_type',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorl2mtl59','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',69,'placeholder','Placeholder',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorlus6lbi','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',4,'fieldname','Name','fieldname','Data','Data',NULL,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorn845cf5','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',19,'default','Default','default','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',0,0,0,0,0),
('iornboecrk','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',2,'label','Label','label','Data','Data',NULL,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'163','163',0,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iornojrrov','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',39,'in_standard_filter','In List Filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioro19ea41','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',46,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: parent.is_submittable',0,0,'50px','50px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorojck3gs','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',71,'oldfieldtype',NULL,'oldfieldtype','Data','Data',NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorophr39u','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',26,'bold','Bold',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorou2kqta','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',70,'oldfieldname',NULL,'oldfieldname','Data','Data',NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorounej9u','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',27,'allow_in_quick_entry','Allow in Quick Entry',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorp0cm2gf','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',61,'display','Display',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorptuomsf','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',67,'description','Description','description','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'300px','300px',0,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iors4d5tr3','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',57,'remember_last_selected_value','Remember Last Selected Value',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.fieldtype == \'Link\')',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iors4p5ap3','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',28,'translatable','Translatable',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\'Data\', \'Select\', \'Text\', \'Small Text\', \'Text Editor\'].includes(doc.fieldtype)',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorsfo6hmg','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',6,'precision','Precision',NULL,'Select',NULL,'\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9',0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\"Float\", \"Currency\", \"Percent\"], doc.fieldtype)',0,0,NULL,NULL,0,NULL,'Set non-standard precision for a Float, Currency or Percent field',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorsi8d4ue','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',38,'in_list_view','In List View',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.is_virtual',0,0,'70px','70px',0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorsosqbil','2021-08-23 17:21:28.345841','2025-10-07 17:58:50.753945','Administrator','Administrator',0,'DocType State','fields','DocType',2,'color','Color',NULL,'Select',NULL,'Blue\nCyan\nGray\nGreen\nLight Blue\nOrange\nPink\nPurple\nRed\nYellow',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Blue',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iortmdvoai','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',15,'sort_options','Sort Options',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.fieldtype === \'Select\'',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iortmokbta','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',62,'print_width','Print Width',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,10,0,0,0,0),
('iortpgq8re','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',8,'hide_days','Hide Days',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Duration\'',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iortqvi6f6','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',49,'make_attachment_public','Make Attachment Public (by default)',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\'Attach\', \'Attach Image\'].includes(doc.fieldtype)',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioru770ujh','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',47,'ignore_user_permissions','Ignore User Permissions',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioru8fmlf5','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',14,'options','Options','options','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'For Links, enter the DocType as range.\nFor Select, enter list of Options, each on a new line.',1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioruel0r8q','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',37,'list__search_settings_section','List / Search Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioruhahaok','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',65,'columns','Columns',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'Number of columns for a field in a List View or a Grid (Total Columns should be less than 11)',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('ioruije6g6','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',13,'column_break_18',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorusf7l54','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',16,'show_dashboard','Show Dashboard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype===\"Tab Break\"',0,0,NULL,NULL,0,'0',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0),
('iorv6fntga','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,'DocField','fields','DocType',21,'fetch_from','Fetch From',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0);
/*!40000 ALTER TABLE `tabDocField` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabDocPerm`
--

DROP TABLE IF EXISTS `tabDocPerm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabDocPerm` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT 0,
  `permlevel` int(11) DEFAULT 0,
  `role` varchar(255) DEFAULT NULL,
  `match` varchar(255) DEFAULT NULL,
  `read` int(1) NOT NULL DEFAULT 1,
  `write` int(1) NOT NULL DEFAULT 1,
  `create` int(1) NOT NULL DEFAULT 1,
  `submit` int(1) NOT NULL DEFAULT 0,
  `cancel` int(1) NOT NULL DEFAULT 0,
  `delete` int(1) NOT NULL DEFAULT 1,
  `amend` int(1) NOT NULL DEFAULT 0,
  `report` int(1) NOT NULL DEFAULT 1,
  `export` int(1) NOT NULL DEFAULT 1,
  `import` int(1) NOT NULL DEFAULT 0,
  `share` int(1) NOT NULL DEFAULT 1,
  `print` int(1) NOT NULL DEFAULT 1,
  `email` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocPerm`
--

LOCK TABLES `tabDocPerm` WRITE;
/*!40000 ALTER TABLE `tabDocPerm` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabDocPerm` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabDocType`
--

DROP TABLE IF EXISTS `tabDocType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabDocType` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `idx` int(8) NOT NULL DEFAULT 0,
  `search_fields` varchar(255) DEFAULT NULL,
  `issingle` int(1) NOT NULL DEFAULT 0,
  `is_virtual` int(1) NOT NULL DEFAULT 0,
  `is_tree` int(1) NOT NULL DEFAULT 0,
  `istable` int(1) NOT NULL DEFAULT 0,
  `editable_grid` int(1) NOT NULL DEFAULT 1,
  `track_changes` int(1) NOT NULL DEFAULT 0,
  `module` varchar(255) DEFAULT NULL,
  `restrict_to_domain` varchar(255) DEFAULT NULL,
  `app` varchar(255) DEFAULT NULL,
  `autoname` varchar(255) DEFAULT NULL,
  `naming_rule` varchar(40) DEFAULT NULL,
  `title_field` varchar(255) DEFAULT NULL,
  `image_field` varchar(255) DEFAULT NULL,
  `timeline_field` varchar(255) DEFAULT NULL,
  `sort_field` varchar(255) DEFAULT NULL,
  `sort_order` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `colour` varchar(255) DEFAULT NULL,
  `read_only` int(1) NOT NULL DEFAULT 0,
  `in_create` int(1) NOT NULL DEFAULT 0,
  `menu_index` int(11) DEFAULT NULL,
  `parent_node` varchar(255) DEFAULT NULL,
  `smallicon` varchar(255) DEFAULT NULL,
  `allow_copy` int(1) NOT NULL DEFAULT 0,
  `allow_rename` int(1) NOT NULL DEFAULT 0,
  `allow_import` int(1) NOT NULL DEFAULT 0,
  `hide_toolbar` int(1) NOT NULL DEFAULT 0,
  `track_seen` int(1) NOT NULL DEFAULT 0,
  `max_attachments` int(11) NOT NULL DEFAULT 0,
  `print_outline` varchar(255) DEFAULT NULL,
  `document_type` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `tag_fields` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `_last_update` varchar(32) DEFAULT NULL,
  `engine` varchar(20) DEFAULT 'InnoDB',
  `default_print_format` varchar(255) DEFAULT NULL,
  `is_submittable` int(1) NOT NULL DEFAULT 0,
  `show_name_in_global_search` int(1) NOT NULL DEFAULT 0,
  `_user_tags` varchar(255) DEFAULT NULL,
  `custom` int(1) NOT NULL DEFAULT 0,
  `beta` int(1) NOT NULL DEFAULT 0,
  `has_web_view` int(1) NOT NULL DEFAULT 0,
  `allow_guest_to_view` int(1) NOT NULL DEFAULT 0,
  `route` varchar(255) DEFAULT NULL,
  `is_published_field` varchar(255) DEFAULT NULL,
  `website_search_field` varchar(255) DEFAULT NULL,
  `email_append_to` int(1) NOT NULL DEFAULT 0,
  `subject_field` varchar(255) DEFAULT NULL,
  `sender_field` varchar(255) DEFAULT NULL,
  `show_title_field_in_link` int(1) NOT NULL DEFAULT 0,
  `migration_hash` varchar(255) DEFAULT NULL,
  `translated_doctype` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType`
--

LOCK TABLES `tabDocType` WRITE;
/*!40000 ALTER TABLE `tabDocType` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tabDocType` VALUES
('DocField','2013-02-22 01:27:33.000000','2025-10-07 17:58:50.786491','Administrator','Administrator',0,1,NULL,0,0,0,1,1,0,'Core',NULL,NULL,'hash','Random',NULL,NULL,NULL,'modified','ASC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,'Setup',NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,NULL,0),
('DocType State','2021-08-23 17:21:28.345841','2021-12-14 14:14:55.716378','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'1fa9b97acbbfcd71792a149fec433496',0);
/*!40000 ALTER TABLE `tabDocType` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabDocType Action`
--

DROP TABLE IF EXISTS `tabDocType Action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabDocType Action` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT 0,
  `label` varchar(140) DEFAULT NULL,
  `group` varchar(140) DEFAULT NULL,
  `action_type` varchar(140) DEFAULT NULL,
  `action` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType Action`
--

LOCK TABLES `tabDocType Action` WRITE;
/*!40000 ALTER TABLE `tabDocType Action` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabDocType Action` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabDocType Link`
--

DROP TABLE IF EXISTS `tabDocType Link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabDocType Link` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT 0,
  `group` varchar(140) DEFAULT NULL,
  `link_doctype` varchar(140) DEFAULT NULL,
  `link_fieldname` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType Link`
--

LOCK TABLES `tabDocType Link` WRITE;
/*!40000 ALTER TABLE `tabDocType Link` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabDocType Link` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabDocType State`
--

DROP TABLE IF EXISTS `tabDocType State`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabDocType State` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `idx` int(8) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `color` varchar(140) DEFAULT 'Blue',
  `custom` int(1) NOT NULL DEFAULT 0,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType State`
--

LOCK TABLES `tabDocType State` WRITE;
/*!40000 ALTER TABLE `tabDocType State` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabDocType State` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabFile`
--

DROP TABLE IF EXISTS `tabFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabFile` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(8) NOT NULL DEFAULT 0,
  `file_name` varchar(255) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `attached_to_name` varchar(255) DEFAULT NULL,
  `file_size` int(11) NOT NULL DEFAULT 0,
  `attached_to_doctype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `attached_to_name` (`attached_to_name`),
  KEY `attached_to_doctype` (`attached_to_doctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabFile`
--

LOCK TABLES `tabFile` WRITE;
/*!40000 ALTER TABLE `tabFile` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabFile` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabSeries`
--

DROP TABLE IF EXISTS `tabSeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabSeries` (
  `name` varchar(100) NOT NULL,
  `current` int(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSeries`
--

LOCK TABLES `tabSeries` WRITE;
/*!40000 ALTER TABLE `tabSeries` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabSeries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabSessions`
--

DROP TABLE IF EXISTS `tabSessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabSessions` (
  `user` varchar(255) DEFAULT NULL,
  `sid` varchar(255) DEFAULT NULL,
  `sessiondata` longtext DEFAULT NULL,
  `ipaddress` varchar(16) DEFAULT NULL,
  `lastupdate` datetime(6) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSessions`
--

LOCK TABLES `tabSessions` WRITE;
/*!40000 ALTER TABLE `tabSessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabSessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tabSingles`
--

DROP TABLE IF EXISTS `tabSingles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabSingles` (
  `doctype` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `value` longtext DEFAULT NULL,
  KEY `singles_doctype_field_index` (`doctype`,`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSingles`
--

LOCK TABLES `tabSingles` WRITE;
/*!40000 ALTER TABLE `tabSingles` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tabSingles` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-10-07 19:35:25
